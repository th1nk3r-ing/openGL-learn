<HTML>
<HEAD>
<TITLE>OpenGL ES SDK</TITLE>
<?php include($_SERVER[DOCUMENT_ROOT] . "/opengles/sdk/inc/sdk_head.txt"); ?>
</HEAD>
<BODY>
<?php include($_SERVER[DOCUMENT_ROOT] . "/opengles/sdk/inc/sdk_body_start.txt"); ?>
<?php include($_SERVER[DOCUMENT_ROOT] . "/opengles/sdk/inc/sdk_footer.txt"); ?>
</BODY>
</HTML>
