http://compgroups.net/comp.graphics.api.opengl/help-on-yuy2-to-rgb-fragment-shader/1116552

Hello everyone:

I wrote two programs for 2D blit a 720x576 image(YUYV). One program
utilized pixel buffer objects(PBO) for uploading the image and we call
it program A. The other program did not use PBO and we call it program
B.

My main method for the two programs was to upload the same image data
twice ( first as GL_BGRA format at 360x576 resolution and second as
GL_LUMINANCE_ALPHA format at 760x576 resolution) so both chroma and
luma components would be interpolated correctly.

The fragment shader is almost the same used in the two programs.
However, program A did not do things right. Program B worked
perfectly. And I cannot figure out why.

Program A result:
http://nagual.hsu.googlepages.com/a.png

Program B result:
http://nagual.hsu.googlepages.com/b.png

Program A source:
http://nagual.hsu.googlepages.com/fs-pbo.c

Program B source:
http://nagual.hsu.googlepages.com/fs.c

Program A,B source and the YUYV image:
http://nagual.hsu.googlepages.com/glsl.tgz

Please give me some hints. Any suggestions would be appreciated.
Thanks.

Forgot to mention that: I ran them in Linux with glut. (Nvidia 7200)