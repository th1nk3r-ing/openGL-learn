#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <signal.h>
#include <unistd.h>
#include <sched.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <errno.h>
#include <GL/glut.h>         /* glut.h includes gl.h and glu.h*/


GLubyte *Ytex, *UVtex;

GLubyte *ioMem[2];
GLuint ioBuf[2], texture_id[2];
GLhandleARB FSHandle,PHandle;

char *FProgram=
	  "uniform sampler2DRect Ytex;\n"
	  "uniform sampler2DRect UVtex;\n"
	  "void main(void) {\n"
	  "  float fx, fy, y, u, v, r, g, b;\n"

	  "  fx   = gl_TexCoord[0].x;\n"	  
	  "  fy   = gl_TexCoord[0].y;\n"

	  "  y = texture2DRect(Ytex,vec2(fx,fy)).r;\n"
	  "  u = texture2DRect(UVtex,vec2(fx/2.0,fy)).g;\n"
	  "  v = texture2DRect(UVtex,vec2(fx/2.0,fy)).a;\n"

  	  "  y=1.164*(y-0.0627);\n"
	  "  u=u-0.5;\n"
	  "  v=v-0.5;\n"
	  "  r = y+1.5958*v;\n"
	  "  g = y-0.39173*u-0.81290*v;\n"
	  "  b = y+2.017*u;\n"
	  "  gl_FragColor=vec4(r, g, b, 1.0);\n"

	  "}\n";

static int init_flag=0;

void show_video(void)
{
	int i;

	
    glActiveTexture(GL_TEXTURE1);
    i=glGetUniformLocationARB(PHandle,"UVtex");
    glUniform1iARB(i,1);  /* for chroma components of YUYV */
	glBindTexture(GL_TEXTURE_RECTANGLE_NV, texture_id[1]);
	glEnable(GL_TEXTURE_RECTANGLE_NV);
	glTexParameteri(GL_TEXTURE_RECTANGLE_NV,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_RECTANGLE_NV,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_DECAL);
	glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT, ioBuf[1]);
	ioMem[1] = (GLubyte *)glMapBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT, GL_WRITE_ONLY);
	memcpy(ioMem[1], UVtex, 360*576*4);
	glUnmapBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT);	
	glTexImage2D(GL_TEXTURE_RECTANGLE_NV,0,GL_RGBA8, 360, 576,0,GL_BGRA,
					GL_UNSIGNED_INT_8_8_8_8_REV, 0);
	glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT, 0);	


    glActiveTexture(GL_TEXTURE0);
	i=glGetUniformLocationARB(PHandle,"Ytex"); /* for Y components of YUYV */
	glUniform1iARB(i,0);  	
	glBindTexture(GL_TEXTURE_RECTANGLE_NV,texture_id[0]);
	glEnable(GL_TEXTURE_RECTANGLE_NV);
	glTexParameteri(GL_TEXTURE_RECTANGLE_NV,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_RECTANGLE_NV,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_DECAL);
	glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT, ioBuf[0]);	
	ioMem[0] = (GLubyte *)glMapBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT, GL_WRITE_ONLY);
	memcpy(ioMem[0], Ytex, 720*576*2);
	glUnmapBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT);	
	glTexImage2D(GL_TEXTURE_RECTANGLE_NV,0, GL_LUMINANCE_ALPHA, 720, 576,0, 
					GL_LUMINANCE_ALPHA,
					GL_UNSIGNED_BYTE, 0);
	glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT, 0);	

	
	glBegin(GL_QUADS);
		glTexCoord2i(0,0);
		glVertex2i(0,720);

		glTexCoord2i(720,0);
		glVertex2i(720,576);

		glTexCoord2i(720,576);
		glVertex2i(720,0);

		glTexCoord2i(0,576);
		glVertex2i(0,0);
	glEnd();
	glFlush();
	glutSwapBuffers();


	glutTimerFunc(33, (void *)show_video, 1);	
	return;
}

void ui_start(void)
{

	int i, j, m, n;
	unsigned char *s;
	FILE *fptr;

	if(init_flag)
		return;

    glShadeModel(GL_FLAT);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 720, 0, 576,-1,1);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glViewport(0, 0, 720, 576);
	
    glClearColor(0,0,0,0);
    glColor3f(1.0,0.84,0.0);
    glHint(GL_POLYGON_SMOOTH_HINT,GL_NICEST);


#if 1
    PHandle=glCreateProgramObjectARB();
    FSHandle=glCreateShaderObjectARB(GL_FRAGMENT_SHADER_ARB);

    glShaderSourceARB(FSHandle,1,&FProgram,NULL);
    glCompileShaderARB(FSHandle);

    glGetObjectParameterivARB(FSHandle,GL_OBJECT_COMPILE_STATUS_ARB,&i);
	s=malloc(32768);
	glGetInfoLogARB(FSHandle,32768,NULL,s);
	printf("Compile Log: %s\n", s);
	free(s);

	glAttachObjectARB(PHandle,FSHandle);
	glLinkProgramARB(PHandle);

	s=malloc(32768);
	glGetInfoLogARB(PHandle,32768,NULL,s);
	printf("Link Log: %s\n", s);
	free(s);

	glUseProgramObjectARB(PHandle);
#endif

   	/* Load the textures. */
	Ytex  = malloc(720*576*2);
	UVtex = malloc(360*576*4);
    fptr=fopen("pic720x576-YUY2.000","rb");
	fread(Ytex, 720*576*2, 1, fptr);
	fclose(fptr);

	memcpy(UVtex, Ytex, 720*576*2);

	/* setting up PBOs */
	glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT, 0);
	glGenBuffersARB(1, &ioBuf[1]); 
	glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT, ioBuf[1]);
	glBufferDataARB(GL_PIXEL_UNPACK_BUFFER_EXT, 720*576*2, 
					NULL, GL_STREAM_DRAW_ARB);
	ioMem[1] = (GLubyte *)glMapBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT, GL_WRITE_ONLY);
	glUnmapBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT); 

	glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT, 0);	
	glGenBuffersARB(1, &ioBuf[0]); 
	glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT, ioBuf[0]);
	glBufferDataARB(GL_PIXEL_UNPACK_BUFFER_EXT, 720*576*2, 
					NULL, GL_STREAM_DRAW_ARB);
	ioMem[0] = (GLubyte *)glMapBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT, GL_WRITE_ONLY);
	glUnmapBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT); 

	glBindBufferARB(GL_PIXEL_UNPACK_BUFFER_EXT, 0);	

	


	glGenTextures(1, &texture_id[0]);		
	glGenTextures(1, &texture_id[1]);	

	glutTimerFunc(33, (void *)show_video, 1);	
	init_flag = 1;
	return;
}

void ui_quit(void)
{
	glUseProgramObjectARB(0);
	glDeleteObjectARB(FSHandle);
	glDeleteObjectARB(PHandle);

	free(UVtex);
	free(Ytex);

	glutLeaveMainLoop();
	return;
}


int main(int argc, char *argv[])
{
	glutInit(&argc,argv); 
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGBA);  
	glutInitWindowSize(720, 576);
	glutInitWindowPosition(0,0); 
	glutCreateWindow("Program A -- with PBO"); 
	glutDisplayFunc(ui_start);
	glutCloseFunc(ui_quit);
	glutMainLoop();
	return 0;
}

