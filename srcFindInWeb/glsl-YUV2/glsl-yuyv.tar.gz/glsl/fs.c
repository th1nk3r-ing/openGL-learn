#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <signal.h>
#include <unistd.h>
#include <sched.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <errno.h>
#include <GL/glut.h>         /* glut.h includes gl.h and glu.h*/

int Quit=0, init_flag=0;

static int B_WIDTH=720;
static int B_HEIGHT=576;

GLubyte *Ytex,*UVtex;
GLhandleARB FSHandle,PHandle;
struct timeval start_time, end_time;

char *FProgram=
	  "uniform sampler2DRect Ytex;\n"
	  "uniform sampler2DRect UVtex;\n"
	  "void main(void) {\n"
	  "  float fx, fy, y, u, v, r, g, b;\n"

	  "  fx   = gl_TexCoord[0].x;\n"	  
	  "  fy   = 576.0-gl_TexCoord[0].y;\n"

	  "  y = texture2DRect(Ytex,vec2(fx,fy)).r;\n"
	  "  u = texture2DRect(UVtex,vec2(fx/2.0,fy)).g;\n"
	  "  v = texture2DRect(UVtex,vec2(fx/2.0,fy)).a;\n"

  	  "  y=1.164*(y-0.0627);\n"
	  "  u=u-0.5;\n"
	  "  v=v-0.5;\n"
	  "  r = y+1.5958*v;\n"
	  "  g = y-0.39173*u-0.81290*v;\n"
	  "  b = y+2.017*u;\n"
	  "  gl_FragColor=vec4(r, g, b, 1.0);\n"

	  "}\n";

void show_video(int value)
{
	int i;

    /* Select texture unit 1 as the active unit and bind the U texture. */
    glActiveTexture(GL_TEXTURE1);
    i=glGetUniformLocationARB(PHandle,"UVtex");
    glUniform1iARB(i,1);  /* Bind Utex to texture unit 1 */
    glBindTexture(GL_TEXTURE_RECTANGLE_NV,1);
    glEnable(GL_TEXTURE_RECTANGLE_NV);
	
    glTexParameteri(GL_TEXTURE_RECTANGLE_NV,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_RECTANGLE_NV,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_DECAL);
    glTexImage2D(GL_TEXTURE_RECTANGLE_NV,0,GL_RGBA8, 360, 576,0,
					GL_BGRA, GL_UNSIGNED_INT_8_8_8_8_REV, UVtex);
	
    /* Select texture unit 0 as the active unit and bind the Y texture. */
    glActiveTexture(GL_TEXTURE0);
    i=glGetUniformLocationARB(PHandle,"Ytex");
    glUniform1iARB(i,0);  /* Bind Ytex to texture unit 0 */
    glBindTexture(GL_TEXTURE_RECTANGLE_NV,2);
    glEnable(GL_TEXTURE_RECTANGLE_NV);
	
    glTexParameteri(GL_TEXTURE_RECTANGLE_NV,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_RECTANGLE_NV,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_DECAL);
    glTexImage2D(GL_TEXTURE_RECTANGLE_NV, 0, GL_LUMINANCE_ALPHA, 720, 576, 0,
					GL_LUMINANCE_ALPHA, GL_UNSIGNED_BYTE,Ytex);

	glBegin(GL_QUADS);
		glTexCoord2i(0,0);
		glVertex2i(0,0);
		glTexCoord2i(720,0);
		glVertex2i(B_WIDTH,0);
		glTexCoord2i(720,576);
		glVertex2i(B_WIDTH,B_HEIGHT);
		glTexCoord2i(0,576);
		glVertex2i(0,B_HEIGHT);
	glEnd();

	glFlush();
	glutSwapBuffers();

	glutTimerFunc(33, show_video, 1);	
	return;
}

void ui_start(void)
{

	int i;
	char *s;
	FILE *fp;
		
	if(init_flag)
		return;

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,B_WIDTH,0,B_HEIGHT,-1,1);
    glViewport(0,0,B_WIDTH,B_HEIGHT);
    glClearColor(0,0,0,0);
    glColor3f(1.0,0.84,0.0);
    glHint(GL_POLYGON_SMOOTH_HINT,GL_NICEST);

    PHandle=glCreateProgramObjectARB();
    FSHandle=glCreateShaderObjectARB(GL_FRAGMENT_SHADER_ARB);

    glShaderSourceARB(FSHandle,1,&FProgram,NULL);
    glCompileShaderARB(FSHandle);

    glGetObjectParameterivARB(FSHandle,GL_OBJECT_COMPILE_STATUS_ARB,&i);
	s=malloc(32768);
	glGetInfoLogARB(FSHandle,32768,NULL,s);
	printf("Compile Log: %s\n", s);
	free(s);

	glAttachObjectARB(PHandle,FSHandle);
	glLinkProgramARB(PHandle);

	s=malloc(32768);
	glGetInfoLogARB(PHandle,32768,NULL,s);
	printf("Link Log: %s\n", s);
	free(s);

	glUseProgramObjectARB(PHandle);

   	/* Load the textures. */
    Ytex=malloc(720*576*2);
    UVtex=malloc(720*576*2);

    fp=fopen("pic720x576-YUY2.000","rb");
   	fread(Ytex, 720*576*2,1,fp);
	fclose(fp);	
	memcpy(UVtex, Ytex, 720*576*2);
	glutTimerFunc(33, show_video, 1);	
	init_flag = 1;
	return;
}

void ui_quit(void)
{
	glUseProgramObjectARB(0);
	glDeleteObjectARB(FSHandle);
	glDeleteObjectARB(PHandle);


    free(Ytex);
    free(UVtex);
	glutLeaveMainLoop();
	return;
}

int main(int argc, char *argv[])
{
	glutInit(&argc,argv); 
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGBA);  
	glutInitWindowSize(B_WIDTH, B_HEIGHT);
	glutInitWindowPosition(0,0); 
	glutCreateWindow("Program B -- without PBO"); 
	glutDisplayFunc(ui_start);
	glutCloseFunc(ui_quit);
	glutMainLoop();
	return 0;
}

